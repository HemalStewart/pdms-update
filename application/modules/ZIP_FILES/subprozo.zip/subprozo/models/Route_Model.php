<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Route_Model extends MY_Model {

    function __construct() {

        parent::__construct();
    }

    public function get_progress_list($user_id) {



        $this->db->select('N.*, S.monthname,U.username as fullname,U.role_id');

        $this->db->from('subprozo_monthlydetails AS N');

        //   $this->db->join('prom_programme AS R', 'R.prozo_id = N.id', 'left');

        $this->db->join('month AS S', 'S.id = N.month', 'left');
        $this->db->join('users AS U', 'U.id = N.user_id', 'left');
       


//        if($this->session->userdata('role_id') != SUPER_ADMIN){
//
//            $this->db->where('N.school_id', $this->session->userdata('school_id'));
//             $this->db->where('N.created_by', $user_id);
//
//        }
//
//         if($this->session->userdata('role_id') == SUPER_ADMIN && $school_id){
//
//            $this->db->where('N.school_id', $school_id);
//
//        }

        $this->db->where('N.status', 1);
        $this->db->where('N.created_by', $user_id);

        $this->db->order_by('N.id', 'DESC');



        return $this->db->get()->result();
    }

    public function get_route_list($school_id = null) {



        $this->db->select('R.*, S.school_name');

        $this->db->from('routes AS R');

        $this->db->join('schools AS S', 'S.id = R.school_id', 'left');



        if ($this->session->userdata('role_id') != SUPER_ADMIN) {

            $this->db->where('R.school_id', $this->session->userdata('school_id'));
        }

        if ($this->session->userdata('role_id') == SUPER_ADMIN && $school_id) {

            $this->db->where('R.school_id', $school_id);
        }

        $this->db->where('S.status', 1);

        $this->db->order_by('R.id', 'DESC');

        return $this->db->get()->result();
    }

    public function get_single_route($route_id) {



        $this->db->select('R.*, S.school_name');

        $this->db->from('routes AS R');

        $this->db->join('schools AS S', 'S.id = R.school_id', 'left');

        $this->db->where('R.id', $route_id);

        return $this->db->get()->row();
    }

    function duplicate_check($school_id, $number, $id = null) {



        if ($id) {

            $this->db->where_not_in('id', $id);
        }

        $this->db->where('school_id', $school_id);

        $this->db->where('title', $number);

        return $this->db->get('routes')->num_rows();
    }

    public function get_single_prozoroute($route_id) {



        $this->db->select('N.*, S.monthname');

        $this->db->from('subprozo_monthlydetails AS N');

        $this->db->join('month AS S', 'S.id = N.month', 'left');

        $this->db->where('N.id', $route_id);

        return $this->db->get()->row();
    }

    public function get_progress_Details($route_id) {



        $this->db->select('N.*, S.program_name,U.program_type');

        $this->db->from('subprom_programme AS N');

     //   $this->db->join('plan_programme AS R', 'R.prozo_id = N.id', 'left');

        
        $this->db->join('subject_program_data AS S', 'S.id = N.program', 'left');
        $this->db->join('subject_program_type AS U', 'U.id = N.program_type', 'left');



        //  $this->db->where('N.status', 1);
        $this->db->where('N.prozo_id', $route_id);

        $this->db->order_by('N.id', 'DESC');



        return $this->db->get()->result();
    }

    public function listprovincial() {

        $this->db->select()->from('provincial');
        $listhostel = $this->db->get();
        return $listhostel->result_array();
    }

    public function getProductData() {

        $this->db->select()->from('subject_program_data');
        $listhostel = $this->db->get();
        return $listhostel->result_array();
    }

    public function getProductType() {

        $this->db->select()->from('subject_program_type');
        $listhostel = $this->db->get();
        return $listhostel->result_array();
    }

    public function getsubjectData() {

        $sub_id = $this->session->userdata('subject_id');
        $str_area = explode(',', $sub_id);
//
        $this->db->select('sub_list.id,sub_list.sub_name,sub_list.sub_code');

        $this->db->from('sub_list');
        $this->db->where_in('sub_list.id', $str_area);
//
        $query = $this->db->get();
        return $query->result_array();
    }

    public function get_listsub() {

        $this->db->select()->from('subjects');
        $listhostel = $this->db->get();
        return $listhostel->result_array();
    }

    public function get_zonal_list($provincial_id) {



        $this->db->select('Z.*');

        $this->db->from('provincial AS P');

        //   $this->db->join('prom_programme AS R', 'R.prozo_id = N.id', 'left');

        $this->db->join('district AS D', 'D.provinceid = P.provincialid', 'left');
        $this->db->join('zone AS Z', 'Z.districtid = D.id', 'left');

        // $this->db->where('N.status', 1);
        $this->db->where('P.provincialid', $provincial_id);

        //     $this->db->order_by('Z.provincialid', 'DESC');



        return $this->db->get()->result_array();
    }

    public function listdistrict($provincial_id) {



        $this->db->select('P.*');

        $this->db->from('district AS P');

        $this->db->where('P.provinceid', $provincial_id);

        return $this->db->get()->result_array();
    }

    public function provincial_id($provincial_id) {



        $this->db->select('P.*');

        $this->db->from('provincial AS P');

        $this->db->where('P.provincialid', $provincial_id);

        return $this->db->get()->row();
    }

    public function pr_data($program_type) {



        $this->db->select('P.*');

        $this->db->from('program_data AS P');

        $this->db->where('P.type_id', $program_type);

        return $this->db->get()->result_array();
    }
    
          public function getsubjectallData() {
        $this->db->select('sub_list.id,sub_list.sub_name,sub_list.sub_code');

        $this->db->from('sub_list');
//
        $query = $this->db->get();
        return $query->result_array();
    }

}
