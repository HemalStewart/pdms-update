<div class="" data-example-id="togglable-tabs">

    <ul  class="nav nav-tabs bordered">

        <li class="active"><a href="#tab_basic_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-info-circle"></i> <?php echo $this->lang->line('profile'); ?></a> </li>

        <li class=""><a href="#tab_social_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('social_link'); ?></a> </li>

          <li class=""><a href="#tab_edu_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('education_qulification'); ?></a> </li>

        <li class=""><a href="#tab_pro_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('profesional_qulification'); ?></a> </li>

        <li class=""><a href="#tab_work_info"   role="tab" data-toggle="tab" aria-expanded="true"><i class="fa fa-share"></i> <?php echo $this->lang->line('working_history'); ?></a> </li>
 
    </ul>

    <br/>



    <div class="tab-content dataTables_wrapper"">

        <div  class="tab-pane fade in active" id="tab_basic_info" > 

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                <tbody>
                    <tr>

                        <th width="20%"><?php echo $this->lang->line('provincial'); ?></th>

                        <td width="30%"><?php echo $teacher->provincialname; ?></td>                      

                        <th width="20%"><?php echo $this->lang->line('district'); ?></th>

                        <td width="30%"><?php echo $teacher->districtname; ?></td>  

                    </tr>

                    <tr>

                        <th width="20%"><?php echo $this->lang->line('zonal'); ?></th>

                        <td width="30%"><?php echo $teacher->zonename; ?></td>                      

                        <th width="20%"><?php echo $this->lang->line('educational'); ?></th>

                        <td width="30%"><?php echo $teacher->zoneblock; ?></td>  

                    </tr>
                    <tr>

                        <th width="20%"><?php echo $this->lang->line('school_name'); ?></th>

                        <td width="30%"><?php echo $teacher->school_name; ?></td>        

                        <th width="20%"><?php echo $this->lang->line('username'); ?></th>

                        <td width="30%"><?php echo $teacher->username; ?></td>        

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('name'); ?></th>

                        <td><?php echo $teacher->name; ?></td>        

                        <th><?php echo $this->lang->line('responsibility'); ?></th>

                        <td><?php echo $teacher->responsibility; ?></td>

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('national_id'); ?></th>

                        <td><?php echo $teacher->national_id; ?></td>        

                        <th><?php echo $this->lang->line('phone'); ?></th>

                        <td><?php echo $teacher->phone; ?></td>

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('present_address'); ?></th>

                        <td><?php echo $teacher->present_address; ?></td>        

                        <th><?php echo $this->lang->line('permanent_address'); ?></th>

                        <td><?php echo $teacher->permanent_address; ?></td>

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('gender'); ?></th>

                        <td><?php echo $this->lang->line($teacher->gender); ?></td>        

                     <th><?php echo $this->lang->line('blood_group'); ?></th>

                        <td><?php echo $this->lang->line($teacher->blood_group); ?></td>

                    </tr>

                      <tr>

                        <th><?php echo $this->lang->line('religion'); ?></th>

                        <td><?php echo $teacher->religion; ?></td>        

                        <th><?php echo $this->lang->line('nationality'); ?></th>

                        <td><?php echo $teacher->nationality ?></td>

                    </tr>
                    
                    <tr>

                        <th><?php echo $this->lang->line('citizenship'); ?></th>

                        <td><?php echo $teacher->citizenship; ?></td>        

                        <th><?php echo $this->lang->line('language'); ?></th>

                        <td><?php echo $teacher->language; ?></td>

                    </tr>
                    
                    <tr>

                        <th><?php echo $this->lang->line('teacher_type'); ?></th>

                        <td><?php echo $teacher->teacher_type; ?></td>
                        
                        <th><?php echo $this->lang->line('ordination_date'); ?></th>

                        <td> 
							<?php if($teacher->ordination_date != '1970-01-01'){
	                          echo date($this->global_setting->date_format, strtotime($teacher->ordination_date));
                                  }else{ 
	                          echo '';
                              } ?>
						</td> 

                         </tr>
                    
                    
                    
                    
                    <!--<tr>-->

                    <!--    <th><?php echo $this->lang->line('religion'); ?></th>-->

                    <!--    <td><?php echo $teacher->religion; ?></td>        -->

                    <!--    <th><?php echo $this->lang->line('birth_date'); ?></th>-->

                    <!--    <td><?php echo date($this->global_setting->date_format, strtotime($teacher->dob)); ?></td>-->

                    <!--</tr>-->
                    
                    
                    <tr>
                        
                        <th><?php echo $this->lang->line('higher_ordination_date'); ?></th>

                        <td>
							 <?php if($teacher->higher_ordination_date != '1970-01-01'){
	                          echo date($this->global_setting->date_format, strtotime($teacher->higher_ordination_date));
                                  }else{ 
	                          echo '';
                              } ?>
									   
						</td>
                        
                        <th><?php echo $this->lang->line('ordination_chapter'); ?></th>

                        <td><?php echo $this->lang->line($teacher->ordination_chapter); ?></td>
                        
                    </tr>
                    
                     <tr>

                        
                        <th><?php echo $this->lang->line('birth_date'); ?></th>

                        <td><?php echo date($this->global_setting->date_format, strtotime($teacher->dob)); ?></td>
                        
                        <th><?php echo $this->lang->line('passport_number'); ?></th>

                        <td><?php echo $this->lang->line($teacher->passport_number); ?></td>
   
                    </tr>
                    
                    <tr>

                        <th><?php echo $this->lang->line('teacher_number'); ?></th>

                        <td><?php echo $this->lang->line($teacher->teacher_number); ?></td>
                        
                        <th><?php echo $this->lang->line('pension_number'); ?></th>

                        <td><?php echo $this->lang->line($teacher->pension_number); ?></td>  
                    </tr>
                    
                     <tr>

                        <th><?php echo $this->lang->line('edcs_number'); ?></th>

                        <td><?php echo $this->lang->line($teacher->edcs_number); ?></td>
                        
                        <th><?php echo $this->lang->line('pension_age'); ?></th>

                        <!--<td><?php echo $this->lang->line($teacher->pension_age); ?></td> -->
                        <td><?php echo $teacher->pension_age; ?></td>
                    </tr>
                    
                    <tr>

                        <th><?php echo $this->lang->line('pension_date'); ?></th>

                        <td><?php echo $teacher->pension_date; ?></td>
                        <!--<td><?php echo $this->lang->line($teacher->pension_date); ?></td>-->
                        
                        <!--<th><?php echo $this->lang->line('pension_age'); ?></th>-->

                        <!--<td><?php echo $this->lang->line($teacher->pension_age); ?></td>-->
                    </tr>


                    <tr>

                        <th><?php echo $this->lang->line('appointment_date2'); ?></th>

                        <td><?php echo date($this->global_setting->date_format, strtotime($teacher->joining_date)); ?></td>        

                        <th><?php echo $this->lang->line('role'); ?></th>

                        <td><?php echo $teacher->role; ?></td>

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('salary_grade'); ?></th>

                        <td><?php echo $teacher->grade_name; ?></td>        

                        <th><?php echo $this->lang->line('salary_type'); ?></th>

                        <!--<td><?php echo $this->lang->line($teacher->salary_type); ?></td>-->
									   <td>
									   <?php  if($teacher->salary_type == 'permanent'){ ?>

                    <a href="javascript:void(0);" class="btn bg-blue btn-xs"> <?php echo $this->lang->line('permanent'); ?> </a>

                <?php  }elseif($teacher->salary_type == 'not_approved'){ ?>

                    <a href="javascript:void(0);" class="btn bg-red btn-xs"><?php echo $this->lang->line('not_approved'); ?> </a>  

                <?php  }elseif($teacher->salary_type == 'temporary'){ ?>

                    <a href="javascript:void(0);" class="btn bg-orange btn-xs"><?php echo $this->lang->line('temporary'); ?> </a>  

                <?php  } ?>
									   
									   </td>			   

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('email'); ?></th>

                        <td><?php echo $teacher->email; ?></td>        

                        <th><?php echo $this->lang->line('other_info'); ?></th>

                        <td><?php echo $teacher->other_info; ?></td>

                    </tr>



                    <tr>

                        <th><?php echo $this->lang->line('photo'); ?></th>

                        <td>

                            <?php if ($teacher->photo) { ?>

                                <img src="<?php echo UPLOAD_PATH; ?>/teacher-photo/<?php echo $teacher->photo; ?>" alt="" width="70" />

                            <?php } ?>

                        </td>        

                        <th><?php echo $this->lang->line('resume'); ?></th>

                        <td>

                            <?php if ($teacher->resume) { ?>

                                <a target="_blank" href="<?php echo UPLOAD_PATH; ?>/teacher-resume/<?php echo $teacher->resume; ?>" class="btn btn-success btn-xs"><i class="fa fa-download"></i> <?php echo $this->lang->line('download'); ?></a>

                            <?php } ?>

                        </td>

                    </tr>                    

                </tbody>

            </table>



        </div>

        <div  class="tab-pane fade in " id="tab_social_info" > 

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                <tbody>



                    <tr>

                        <th><?php echo $this->lang->line('facebook_url'); ?></th>

                        <td><?php echo $teacher->facebook_url; ?></td>        

                        <th><?php echo $this->lang->line('linkedin_url'); ?></th>

                        <td><?php echo $teacher->linkedin_url; ?></td>

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('twitter_url'); ?></th>

                        <td><?php echo $teacher->twitter_url; ?></td>    
                        
                        <th><?php echo $this->lang->line('youtube_url'); ?></th>

                        <td><?php echo $teacher->youtube_url; ?></td> 

                       <!-- <th><?php echo $this->lang->line('google_plus_url'); ?></th>

                        <td><?php echo $teacher->google_plus_url; ?></td>-->

                    </tr>

                    <tr>

                        <th><?php echo $this->lang->line('instagram_url'); ?></th>

                        <td><?php echo $teacher->instagram_url; ?></td>        

                        <th><?php echo $this->lang->line('pinterest_url'); ?></th>

                        <td><?php echo $teacher->pinterest_url; ?></td>

                    </tr>

                   <!-- <tr>

                        <th><?php echo $this->lang->line('youtube_url'); ?></th>

                        <td><?php echo $teacher->youtube_url; ?></td>        

                        <th><?php echo $this->lang->line('is_view_on_web'); ?></th>

                        <td><?php echo $teacher->is_view_on_web ? $this->lang->line('yes') : $this->lang->line('no'); ?></td>
-->
                    </tr>

                </tbody>

            </table>

        </div>
        
        

        <div  class="tab-pane fade in " id="tab_edu_info" > 

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                <tbody>



                    <tr>               

                        <th><?php echo $this->lang->line('tea_qutype'); ?></th>

                        <th><?php echo $this->lang->line('tea_head'); ?></th>

                        <th><?php echo $this->lang->line('tea_univinstitute'); ?></th>

                        <th><?php echo $this->lang->line('tea_year'); ?></th>

                        <th><?php echo $this->lang->line('tea_class'); ?></th>



                    </tr>

                    <?php foreach ($teacher_edu as $obj) { ?> 

                        <tr>  

                            <td><?php echo $obj->teach_qutype; ?></td>

                            <td><?php echo $obj->teach_head; ?></td>

                            <td><?php echo $obj->teach_univinstitute; ?></td>

                            <td><?php echo $obj->teach_year; ?></td>

                            <td><?php echo $obj->teach_class; ?></td>

                        </tr>

                    <?php } ?>
                </tbody>

            </table>

        </div>
        
        
        <div  class="tab-pane fade in " id="tab_pro_info" > 

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                <tbody>



                    <tr>               

                        <th><?php echo $this->lang->line('tea_qutype'); ?></th>

                        <th><?php echo $this->lang->line('tea_head'); ?></th>

                        <th><?php echo $this->lang->line('tea_univinstitute'); ?></th>

                        <th><?php echo $this->lang->line('tea_year'); ?></th>

                        <th><?php echo $this->lang->line('tea_class'); ?></th>



                    </tr>

                    <?php foreach ($teacher_pru as $obj) { ?> 

                        <tr>  

                            <td><?php echo $obj->teach_qutype; ?></td>

                            <td><?php echo $obj->teach_head; ?></td>

                            <td><?php echo $obj->teach_univinstitute; ?></td>

                            <td><?php echo $obj->teach_year; ?></td>

                            <td><?php echo $obj->teach_class; ?></td>

                        </tr>

                    <?php } ?>
                </tbody>

            </table>

        </div>
        
        
        
        <div  class="tab-pane fade in " id="tab_work_info" > 

            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">

                <tbody>



                    <tr>               

                        <th><?php echo $this->lang->line('work_pirivena'); ?></th>

                        <th><?php echo $this->lang->line('work_address'); ?></th>

                        <th><?php echo $this->lang->line('work_from'); ?></th>

                        <th><?php echo $this->lang->line('work_to'); ?></th>

                        <th><?php echo $this->lang->line('work_tranfer'); ?></th>



                    </tr>

                    <?php foreach ($teacher_work as $obj) { ?> 

                        <tr>  

                            <td><?php echo $obj->working_pirivena; ?></td>

                            <td><?php echo $obj->working_address; ?></td>

                            <td><?php echo $obj->working_from; ?></td>

                            <td><?php echo $obj->working_to; ?></td>

                            <td><?php echo $obj->working_tranfer; ?></td>

                        </tr>

                    <?php } ?>
                </tbody>

            </table>

        </div>

    </div>

</div>